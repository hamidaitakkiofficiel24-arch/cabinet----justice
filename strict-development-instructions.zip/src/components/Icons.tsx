type IconProps = {
  className?: string;
};

export function CourtLogo({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 54" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.15" strokeLinecap="round" strokeLinejoin="round">
        <path d="M24 3 5 17h38L24 3Z" />
        <path d="m24 7 13 9H11l13-9Z" opacity=".65" />
        <path d="M8 20h32M6 23h36M8 45h32M5 48h38M3 51h42" />
        <path d="M11 24v18M17 24v18M24 24v18M31 24v18M37 24v18" />
        <path d="M9 42h30M10 25h5M15 25h5M22 25h5M29 25h5M35 25h4" opacity=".75" />
        <circle cx="24" cy="5" r="1.7" />
      </g>
    </svg>
  );
}

export function GavelIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round">
        <path d="m12 12 7-7 12 12-7 7L12 12Z" />
        <path d="m9 16 7-7M27 22l7-7" />
        <path d="m22 21-13 13M7 32l5 5" />
        <path d="M20 39h21M24 35h13l3 4H20l4-4Z" />
        <path d="M15 9l12 12" stroke="var(--icon-accent, currentColor)" />
      </g>
    </svg>
  );
}

export function ScalesIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="24" cy="6" r="2.2" />
        <path d="M24 9v29M17 39h14M14 43h20M19 39l2-4h6l2 4M9 14h30M24 11 9 14l-4 9M24 11l15 3 4 9" />
        <path d="m9 14-4 9M9 14l4 9M39 14l-4 9M39 14l4 9" />
        <path d="M3 24c1 5 11 5 12 0H3ZM33 24c1 5 11 5 12 0H33Z" />
        <path d="M14 12h20" stroke="var(--icon-accent, currentColor)" />
      </g>
    </svg>
  );
}

export function ShieldIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round">
        <path d="M24 4c5 4 10 5 15 6v12c0 10-6 17-15 22C15 39 9 32 9 22V10c5-1 10-2 15-6Z" />
        <path d="M24 8c4 3 8 4 11 4v10c0 8-4 13-11 17-7-4-11-9-11-17V12c3 0 7-1 11-4Z" opacity=".7" />
        <path d="m24 14 2.5 5 5.5.8-4 3.9.9 5.5-4.9-2.6-4.9 2.6.9-5.5-4-3.9 5.5-.8 2.5-5Z" stroke="var(--icon-accent, currentColor)" />
      </g>
    </svg>
  );
}

export function BriefcaseIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 40" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.15" strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 12h36v23H6V12Z" />
        <path d="M17 12V8h14v4M20 8V5h8v3M6 20l14 5h8l14-5" />
        <path d="M20 23h8v6h-8zM24 25v2" />
      </g>
    </svg>
  );
}

export function GraduationIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 40" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.15" strokeLinecap="round" strokeLinejoin="round">
        <path d="m24 5 20 9-20 9L4 14l20-9Z" />
        <path d="M12 18v10c6 7 18 7 24 0V18M42 15v13" />
        <path d="M39 31h6M16 28c4 3 12 3 16 0" />
      </g>
    </svg>
  );
}

export function MarriageIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 56 40" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="17" cy="10" r="5" />
        <circle cx="39" cy="10" r="5" />
        <path d="M9 29v-7c0-5 3-8 8-8s8 3 8 8v7M31 29v-7c0-5 3-8 8-8s8 3 8 8v7" />
        <path d="M5 29h46M8 34h40M17 15v5l-4 3M39 15v5l4 3M25 22h6" />
        <path d="M13 7c1-4 7-4 8 0M35 7c1-4 7-4 8 0" />
      </g>
    </svg>
  );
}

export function RealEstateIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 40" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round">
        <path d="m24 4 19 12H5L24 4ZM8 19h32M6 34h36M4 38h40" />
        <path d="M10 20v12M17 20v12M24 20v12M31 20v12M38 20v12" />
        <path d="m17 12 7-5 7 5M21 12v-3h6v3" />
      </g>
    </svg>
  );
}

export function TechCircleIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 56 48" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="3" strokeLinecap="square" strokeLinejoin="miter">
        <path d="M45 13A20 20 0 1 0 47 31M40 9l7 4-1 8" />
        <path d="M15 18h24v18l-12-8-12 8V18Z" />
        <path d="m16 18 11 10 12-10M27 28v12" />
      </g>
    </svg>
  );
}

export function TechAIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 56 48" fill="none" aria-hidden="true">
      <path d="M6 42 23 5h10L17 42H6Zm20 0L39 12l12 30H38l-6-17-7 17h1Z" fill="currentColor" />
    </svg>
  );
}

export function TechXIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 64 48" fill="none" aria-hidden="true">
      <path d="m20 15 24 18M44 15 20 33" stroke="currentColor" strokeWidth="7" strokeLinecap="round" />
      <g fill="currentColor">
        <circle cx="13" cy="4" r="2.4" /><circle cx="51" cy="4" r="2.4" />
        <circle cx="13" cy="36" r="2.4" /><circle cx="51" cy="36" r="2.4" />
      </g>
    </svg>
  );
}

export function TechApertureIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 56 48" fill="none" aria-hidden="true">
      <g fill="currentColor">
        <path d="M23 3h15l-6 12H17L23 3Z" />
        <path d="m40 6 8 13-12 3-5-12 9-4Z" />
        <path d="m49 22-5 15-12-7 5-12 12 4Z" />
        <path d="M33 45H18l6-12h15l-6 12Z" />
        <path d="m16 42-8-13 12-3 5 12-9 4Z" />
        <path d="M7 26 12 11l12 7-5 12L7 26Z" />
      </g>
    </svg>
  );
}

export function TechDiamondIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 56 48" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="3">
        <path d="m28 7 16 17-16 17L12 24 28 7Z" />
        <path d="m28 15 9 9-9 9-9-9 9-9Z" />
        <path d="M5 5h8v8H5zM43 5h8v8h-8zM5 35h8v8H5zM43 35h8v8h-8z" fill="currentColor" stroke="none" />
      </g>
    </svg>
  );
}

export function ClockIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="10" cy="10" r="6.7" stroke="currentColor" strokeWidth="1.2" />
      <path d="M10 6.3v4l2.8 1.6" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

export function MapPinIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M15.5 8c0 4.2-5.5 8.5-5.5 8.5S4.5 12.2 4.5 8a5.5 5.5 0 1 1 11 0Z" stroke="currentColor" strokeWidth="1.15" strokeLinejoin="round" />
      <circle cx="10" cy="8" r="1.9" stroke="currentColor" strokeWidth="1.15" />
    </svg>
  );
}

export function PhoneIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M6.2 3.2 8 7.4 6.5 9c.9 2 2.4 3.5 4.5 4.5l1.6-1.6 4.2 1.9-.5 3c-7.4.7-14.6-6.5-13.9-13.9l3.8-.4Z" stroke="currentColor" strokeWidth="1.15" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function MailIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="2.5" y="4.5" width="15" height="11" stroke="currentColor" strokeWidth="1.15" />
      <path d="m3.5 5.5 6.5 5 6.5-5" stroke="currentColor" strokeWidth="1.15" strokeLinejoin="round" />
    </svg>
  );
}

export function TwitterIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M16.5 5.2c-.5.2-1 .4-1.5.4a2.6 2.6 0 0 0-4.4 2.4A7.4 7.4 0 0 1 4 4.7c-.9 1.5-.4 3.4.9 4.2-.4 0-.8-.1-1.2-.3 0 1.9 1.3 3.2 3 3.5-.4.1-.8.1-1.2.1.4 1.3 1.6 2.2 3 2.2A7.4 7.4 0 0 1 3 15.7a10.4 10.4 0 0 0 5.6 1.6c6.7 0 9.4-6.5 9.2-9.4.7-.5 1.2-1.1 1.7-1.8-.7.3-1.4.5-2.1.6.8-.5 1.3-1.2 1.6-2.1-.8.5-1.6.8-2.5 1Z" fill="currentColor" transform="scale(.82) translate(2 1)" />
    </svg>
  );
}

export function FacebookIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M11.5 17v-6h2l.4-2.5h-2.4V6.9c0-.8.3-1.4 1.5-1.4h1.1V3.2c-.3 0-1.1-.1-2-.1-2 0-3.4 1.2-3.4 3.5v1.9H6.5V11h2.2v6h2.8Z" fill="currentColor" />
    </svg>
  );
}

export function InstagramIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="4" y="4" width="12" height="12" rx="3" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="10" cy="10" r="2.8" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="13.7" cy="6.4" r=".8" fill="currentColor" />
    </svg>
  );
}

export function PinterestIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M10 3a7 7 0 0 0-2.5 13.5c-.1-1.1 0-2.4.3-3.4l1-4s-.3-.7-.3-1.6c0-1.5.9-2.6 2-2.6.9 0 1.4.7 1.4 1.6 0 1-.6 2.4-.9 3.7-.3 1.1.5 2 1.6 2 1.9 0 3.3-2 3.3-4.8 0-2.5-1.8-4.3-4.4-4.3-3 0-4.8 2.3-4.8 4.6 0 .9.3 1.9.8 2.4" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
    </svg>
  );
}

export function LinkedinIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M5 7.5V16M5 4.5v.2M9 16v-4.5c0-2 4.5-2.5 4.5 0V16M9 8v8" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

export function SearchIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="8.4" cy="8.4" r="4.8" stroke="currentColor" strokeWidth="1.35" />
      <path d="m12 12 4 4" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" />
    </svg>
  );
}

export function ChevronIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="m5.5 3.5 4.5 4.5-4.5 4.5" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function ArrowIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M3 10h13M11.5 5.5 16 10l-4.5 4.5" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
