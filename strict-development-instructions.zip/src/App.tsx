import { useEffect, useRef, useState, type CSSProperties, type FormEvent } from "react";
import {
  ArrowIcon,
  BriefcaseIcon,
  ChevronIcon,
  ClockIcon,
  CourtLogo,
  FacebookIcon,
  GavelIcon,
  GraduationIcon,
  InstagramIcon,
  LinkedinIcon,
  MailIcon,
  MapPinIcon,
  MarriageIcon,
  PhoneIcon,
  PinterestIcon,
  RealEstateIcon,
  ScalesIcon,
  SearchIcon,
  ShieldIcon,
  TechAIcon,
  TechApertureIcon,
  TechCircleIcon,
  TechDiamondIcon,
  TechXIcon,
  TwitterIcon,
} from "./components/Icons";
import { useScrollReveal } from "./hooks/useScrollReveal";

const blogPosts = [
  {
    id: "divorce-uk",
    date: "October 8, 2025",
    title: "Divorce in the UK Today",
    url: "https://www.gov.uk/divorce",
  },
  {
    id: "family-domestic",
    date: "October 15, 2025",
    title: "Week Family Law Domestic",
    url: "https://www.americanbar.org/groups/family_law/resources/family-advocate/client-manuals/",
  },
  {
    id: "marriage-us",
    date: "October 10, 2025",
    title: "Flexibility of Marriage in US",
    url: "https://www.usa.gov/request-documents",
  },
];

const testimonials = [
  {
    name: "Sarah Mitchell",
    role: "FOUNDER & CREATIVE DIRECTOR",
    rating: 4,
    quote: [
      "\"The team handled my contractual dispute with patience and remarkable",
      "attention to detail. I always knew where the case stood, and their strategic",
      "approach brought about a fair resolution without unnecessary delays.\"",
    ],
  },
  {
    name: "Jordan Billy",
    role: "MANAGING DIRECTOR OF COMPANY",
    rating: 5,
    quote: [
      "\"Justix guided our company through a complex restructuring with clarity and",
      "precision. Every step was explained carefully, deadlines were respected, and",
      "their advice consistently protected our long-term interests.\"",
    ],
  },
  {
    name: "Daniel Robertson",
    role: "OPERATIONS DIRECTOR",
    rating: 5,
    quote: [
      "\"From the first consultation, Justix combined legal expertise with genuine",
      "care. Communication was prompt, every document was reviewed thoroughly, and",
      "I felt confident in each decision throughout the entire process.\"",
    ],
  },
];

const services = [
  {
    id: "legal-professional-law",
    title: ["Legal Professional", "Law"],
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
    Icon: GavelIcon,
    featured: false,
  },
  {
    id: "international-law-justice",
    title: ["International Law", "and Justice"],
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
    Icon: ScalesIcon,
    featured: true,
  },
  {
    id: "protection-of-consumer",
    title: ["Protection of", "Consumer"],
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
    Icon: ShieldIcon,
    featured: false,
  },
];

async function shareJustix() {
  const shareData = { title: "Justix", url: window.location.href };

  if (navigator.share) {
    try {
      await navigator.share(shareData);
      return;
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
    }
  }

  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(shareData.url);
      return;
    } catch {
      // Continue with the local selection fallback when clipboard access is denied.
    }
  }

  const textArea = document.createElement("textarea");
  textArea.value = shareData.url;
  textArea.style.position = "fixed";
  textArea.style.opacity = "0";
  document.body.appendChild(textArea);
  textArea.select();
  try {
    document.execCommand("copy");
  } catch {
    // Sharing is unavailable in this browser; no success is claimed.
  } finally {
    textArea.remove();
  }
}

export default function App() {
  useScrollReveal();
  const [pagesOpen, setPagesOpen] = useState(false);
  const [blogOrder, setBlogOrder] = useState([0, 1, 2]);
  const [activeTestimonial, setActiveTestimonial] = useState(1);
  const [searchOpen, setSearchOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSaved, setNewsletterSaved] = useState(false);
  const [query, setQuery] = useState("");
  const [searchMessage, setSearchMessage] = useState("");
  const [highlighted, setHighlighted] = useState("");
  const headerRef = useRef<HTMLElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const highlightTimer = useRef<number | undefined>(undefined);
  const shareUrl = encodeURIComponent(window.location.href);
  const currentTestimonial = testimonials[activeTestimonial];

  useEffect(() => {
    const handlePointerDown = (event: PointerEvent) => {
      if (headerRef.current && !headerRef.current.contains(event.target as Node)) {
        setPagesOpen(false);
        setSearchOpen(false);
        setMenuOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setPagesOpen(false);
        setSearchOpen(false);
        setMenuOpen(false);
      }
    };

    document.addEventListener("pointerdown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
      window.clearTimeout(highlightTimer.current);
    };
  }, []);

  useEffect(() => {
    if (searchOpen) searchInputRef.current?.focus();
  }, [searchOpen]);

  const goToService = (id: string) => {
    setPagesOpen(false);
    setSearchOpen(false);
    setMenuOpen(false);
    setSearchMessage("");
    setHighlighted(id);

    const card = document.getElementById(id);
    card?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      block: "center",
    });
    card?.focus({ preventScroll: true });

    window.clearTimeout(highlightTimer.current);
    highlightTimer.current = window.setTimeout(() => setHighlighted(""), 1800);
  };

  const handleSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const normalizedQuery = query.trim().toLowerCase();

    if (!normalizedQuery) {
      setSearchMessage("Enter a service name.");
      return;
    }

    const match = services.find((service) =>
      service.title.join(" ").toLowerCase().includes(normalizedQuery),
    );

    if (match) {
      goToService(match.id);
      setQuery("");
    } else {
      setSearchMessage("No matching service.");
    }
  };

  const handleNewsletterSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    try {
      window.localStorage.setItem("justix-newsletter-email", newsletterEmail.trim());
      setNewsletterEmail("");
      setNewsletterSaved(true);
    } catch {
      setNewsletterSaved(false);
    }
  };

  return (
    <main className="page-shell">
      <section className="hero" id="home" aria-labelledby="hero-title">
        <header className="site-header" ref={headerRef}>
          <a className="brand" href="#home" aria-label="Law firm home">
            <CourtLogo className="brand__mark" />
          </a>

          <button
            className="menu-toggle"
            type="button"
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
          >
            <span />
            <span />
            <span />
          </button>

          <nav className={`main-nav${menuOpen ? " main-nav--open" : ""}`} aria-label="Main navigation">
            <a href="#home" onClick={() => setMenuOpen(false)}>HOME</a>
            <a href="#about-us" onClick={() => setMenuOpen(false)}>ABOUT US</a>
            <div className="pages-nav">
              <button
                className="pages-nav__trigger"
                type="button"
                aria-expanded={pagesOpen}
                aria-controls="pages-menu"
                onClick={() => setPagesOpen((open) => !open)}
              >
                PAGES
                <ChevronIcon className={`pages-nav__chevron${pagesOpen ? " is-open" : ""}`} />
              </button>
              <div className={`pages-menu${pagesOpen ? " pages-menu--open" : ""}`} id="pages-menu">
                {services.map((service) => (
                  <button key={service.id} type="button" onClick={() => goToService(service.id)}>
                    {service.title.join(" ")}
                  </button>
                ))}
              </div>
            </div>
            <a href="#our-blog" onClick={() => setMenuOpen(false)}>BLOG</a>
            <a href="#contact" onClick={() => setMenuOpen(false)}>CONTACT</a>
          </nav>

          <div className="header-meta">
            <span className="header-meta__item">
              <ClockIcon className="header-meta__icon" />
              9AM - 9PM
            </span>
            <a className="header-meta__item header-meta__phone" href="tel:+0123456789">
              <PhoneIcon className="header-meta__icon" />
              +0123456789
            </a>
            <button
              className="search-toggle"
              type="button"
              aria-label="Search services"
              aria-expanded={searchOpen}
              onClick={() => {
                setSearchOpen((open) => !open);
                setSearchMessage("");
              }}
            >
              <SearchIcon className="header-meta__icon" />
            </button>
          </div>

          <form
            className={`service-search${searchOpen ? " service-search--open" : ""}`}
            role="search"
            onSubmit={handleSearch}
            aria-hidden={!searchOpen}
          >
            <label className="sr-only" htmlFor="service-query">Search services</label>
            <input
              id="service-query"
              ref={searchInputRef}
              type="search"
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setSearchMessage("");
              }}
              placeholder="Search services"
              tabIndex={searchOpen ? 0 : -1}
            />
            <button type="submit" aria-label="Submit search" tabIndex={searchOpen ? 0 : -1}>
              <SearchIcon />
            </button>
            {searchMessage && <span className="service-search__message" role="status">{searchMessage}</span>}
          </form>
        </header>

        <div className="header-rule" aria-hidden="true" />

        <div className="hero-content">
          <p className="eyebrow">WE FIGHT FOR JUSTICE</p>
          <h1 id="hero-title">
            <span className="title-mask"><span>Always Respect</span></span>
            <span className="title-mask"><span><em>Justice</em> of The Law</span></span>
          </h1>
          <p className="hero-description">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            exercitation ullamco.
          </p>
          <a className="consultation-button" id="free-consultation" href="tel:+0123456789">
            <span>FREE CONSULTATION</span>
            <span className="consultation-button__arrow" aria-hidden="true">
              <ChevronIcon />
            </span>
          </a>
        </div>

        <div className="services-wrap" id="services">
          <div className="services-grid">
            {services.map((service, index) => {
              const Icon = service.Icon;
              return (
                <article
                  className={`service-card${service.featured ? " service-card--featured" : ""}${highlighted === service.id ? " service-card--highlighted" : ""}`}
                  id={service.id}
                  key={service.id}
                  tabIndex={-1}
                  style={{ "--card-delay": `${300 + index * 90}ms` } as CSSProperties}
                >
                  <div className="service-card__heading">
                    <Icon className="service-card__icon" />
                    <h2>
                      <span>{service.title[0]}</span>
                      <span>{service.title[1]}</span>
                    </h2>
                  </div>
                  <div className="service-card__rule" aria-hidden="true" />
                  <p>{service.description}</p>
                  <a className="service-card__link" href="#free-consultation">
                    GET STARTED
                    <ArrowIcon />
                  </a>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="about-section" id="about-us" aria-labelledby="about-title">
        <div className="about-inner">
          <div className="about-copy">
            <p className="about-eyebrow">ABOUT JUSTIX</p>
            <h2 id="about-title">
              <span>The <em>Leading</em> Law Firm</span>
              <span>for Annual Revenues</span>
            </h2>
            <p className="about-description">
              <span>Lorem ipsum dolor sit amet, consectetur adipiscing</span>
              <span>elit, sed do eiusmod tempor incididunt ut labore et</span>
              <span>dolore magna aliqua. Ut enim ad minim veniam, quis</span>
              <span>nostrud exercitation ullamco laboris.</span>
            </p>
            <div className="about-divider" aria-hidden="true" />
            <div className="about-signature">
              <p className="about-signature__name">Alex Moore</p>
              <p className="about-signature__role">FOUNDER &amp; CEO JUSTIX</p>
            </div>
          </div>

          <div className="about-visual">
            <div className="experience-badge">
              <strong>20+</strong>
              <span>YEARS<br />EXPERIENCE</span>
            </div>
          </div>
        </div>
      </section>

      <section className="cases-section" id="case-studies" aria-labelledby="cases-title">
        <div className="cases-heading">
          <p>OUR BEST WORK</p>
          <h2 id="cases-title">Our <em>Recent</em> Case Studies</h2>
        </div>

        <div className="cases-grid">
          <div className="cases-stack">
            <article className="case-card">
              <h3><span>International Law</span><span>&amp; Justice</span></h3>
              <div className="case-card__symbol">
                <BriefcaseIcon />
              </div>
            </article>
            <article className="case-card">
              <h3><span>Competition &amp;</span><span>Antitrust</span></h3>
              <div className="case-card__symbol">
                <GraduationIcon />
              </div>
            </article>
          </div>

          <div className="cases-center" aria-hidden="true" />

          <div className="cases-stack">
            <article className="case-card case-card--featured">
              <h3><span>Marriage Contract</span><span>in Law</span></h3>
              <div className="case-card__symbol">
                <MarriageIcon />
              </div>
            </article>
            <article className="case-card">
              <h3><span>Real Estate Law</span><span>Firms</span></h3>
              <div className="case-card__symbol">
                <RealEstateIcon />
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="solve-section" aria-labelledby="solve-title">
        <h2 id="solve-title">Solve Your <em>Problem</em> With Us</h2>
        <p className="solve-description">
          <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</span>
          <span>incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</span>
          <span>exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</span>
        </p>
        <a className="solve-button" href="tel:+0123456789">
          <span>FREE CONSULTATION</span>
          <span className="solve-button__arrow" aria-hidden="true">
            <ChevronIcon />
          </span>
        </a>
      </section>

      <section className="testimonials-section" id="testimonials" aria-labelledby="testimonials-title">
        <div className="testimonials-inner">
          <div className="testimonials-heading">
            <p>TESTIMONIALS</p>
            <h2 id="testimonials-title">What Our <em>Clients</em> Say</h2>
          </div>

          <div className="testimonial-avatars">
            <button
              className="testimonial-arrow testimonial-arrow--left"
              type="button"
              aria-label="Previous testimonial"
              aria-controls="testimonial-content"
              onClick={() => setActiveTestimonial((current) => (current - 1 + testimonials.length) % testimonials.length)}
            >
              <ChevronIcon />
            </button>
            <div className="testimonial-avatar-strip" aria-hidden="true">
              <span className="testimonial-avatar testimonial-avatar--1" />
              <span className="testimonial-avatar testimonial-avatar--2" />
              <span className="testimonial-avatar testimonial-avatar--active" />
              <span className="testimonial-avatar testimonial-avatar--4" />
              <span className="testimonial-avatar testimonial-avatar--5" />
            </div>
            <button
              className="testimonial-arrow testimonial-arrow--right"
              type="button"
              aria-label="Next testimonial"
              aria-controls="testimonial-content"
              onClick={() => setActiveTestimonial((current) => (current + 1) % testimonials.length)}
            >
              <ChevronIcon />
            </button>
          </div>

          <p className="testimonial-name" aria-live="polite">{currentTestimonial.name}</p>
          <p className="testimonial-role">{currentTestimonial.role}</p>
          <blockquote className="testimonial-quote" id="testimonial-content" aria-live="polite">
            {currentTestimonial.quote.map((line, index) => <span key={index}>{line}</span>)}
          </blockquote>
          <div className="testimonial-rating" role="img" aria-label={`${currentTestimonial.rating} out of 5 stars`}>
            {Array.from({ length: 5 }, (_, index) => (
              <span className={index >= currentTestimonial.rating ? "is-muted" : ""} key={index} />
            ))}
          </div>
          <div className="testimonial-pagination" aria-label="Choose a testimonial">
            {testimonials.map((testimonial, index) => (
              <button
                className={index === activeTestimonial ? "is-active" : ""}
                type="button"
                aria-label={`Show testimonial from ${testimonial.name}`}
                aria-current={index === activeTestimonial ? "true" : undefined}
                onClick={() => setActiveTestimonial(index)}
                key={testimonial.name}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="blog-section" id="our-blog" aria-labelledby="blog-title">
        <div className="blog-heading">
          <p>OUR BLOG</p>
          <h2 id="blog-title">Recent <em>News</em> From The Industry</h2>
        </div>

        <div className="blog-grid" aria-live="polite">
          {blogOrder.map((postIndex, position) => {
            const post = blogPosts[postIndex];
            const featured = position === 1;
            return (
              <article className={`blog-card${featured ? " blog-card--featured" : ""}`} key={post.id}>
                <div className="blog-card__visual">
                  <span>FAMILY LAW</span>
                </div>
                <time>{post.date}</time>
                <h3>{post.title}</h3>
                <p className="blog-card__excerpt">
                  <span>Lorem ipsum dolor sit amet, consectetur</span>
                  <span>adipiscing elit, sed do eiusmod tempor</span>
                  <span>incididunt ut labore et...</span>
                </p>
                <a
                  className="blog-card__read-more"
                  href={post.url}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={`Read more about ${post.title}`}
                >
                  READ MORE
                  <ArrowIcon />
                </a>
              </article>
            );
          })}
        </div>

        <button
          className="blog-more-button"
          type="button"
          onClick={() => setBlogOrder(([first, ...rest]) => [...rest, first])}
        >
          <span>FIND ANOTHER BLOG</span>
          <span className="blog-more-button__arrow" aria-hidden="true">
            <ChevronIcon />
          </span>
        </button>
      </section>

      <section className="brands-section" aria-label="Techbrand">
        <div className="brands-strip">
          <div className="brand-item brand-item--1">
            <TechCircleIcon className="brand-symbol" />
            <span className="brand-name">TECHBRAND</span>
            <span className="brand-tagline">YOUR TAGLINE HERE</span>
          </div>
          <div className="brand-item brand-item--2">
            <TechAIcon className="brand-symbol" />
            <span className="brand-name">TECHBRAND</span>
            <span className="brand-tagline">YOUR TAGLINE HERE</span>
          </div>
          <div className="brand-item brand-item--3 brand-item--featured">
            <TechXIcon className="brand-symbol" />
            <span className="brand-name">TECHBRAND</span>
            <span className="brand-tagline">YOUR TAGLINE HERE</span>
          </div>
          <div className="brand-item brand-item--4">
            <TechApertureIcon className="brand-symbol" />
            <span className="brand-name">TECHBRAND</span>
            <span className="brand-tagline">YOUR TAGLINE HERE</span>
          </div>
          <div className="brand-item brand-item--5">
            <TechDiamondIcon className="brand-symbol" />
            <span className="brand-name">TECHBRAND</span>
            <span className="brand-tagline">YOUR TAGLINE HERE</span>
          </div>
        </div>
      </section>

      <section className="contact-section" id="contact" aria-labelledby="contact-title">
        <div className="contact-frame">
          <div className="contact-layout">
            <div className="contact-visual" aria-hidden="true" />
            <div className="contact-info">
              <p className="contact-eyebrow">CONTACT US</p>
              <h2 id="contact-title">
                <span>Get Your Free</span>
                <span><em>Consultation</em> Today</span>
              </h2>
              <p className="contact-description">
                <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do</span>
                <span>eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                <span>Ut enim ad minim veniam.</span>
              </p>

              <div className="contact-grid">
                <article className="contact-card contact-card--open">
                  <h3><span>We&apos;re Open at</span><span>9AM - 9PM</span></h3>
                  <div className="contact-card__symbol"><ClockIcon /></div>
                </article>
                <article className="contact-card">
                  <h3>
                    <a
                      className="contact-card__action"
                      href="https://www.google.com/maps/dir/?api=1&destination=15%20Division%20st%2C%20New%20York%2C%2016004"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <span>15 Division st, New</span><span>York, 16004</span>
                    </a>
                  </h3>
                  <div className="contact-card__symbol"><MapPinIcon /></div>
                </article>
                <article className="contact-card">
                  <h3><span>Call Us</span><a className="contact-card__action" href="tel:+0123456789">+0123456789</a></h3>
                  <div className="contact-card__symbol"><PhoneIcon /></div>
                </article>
                <a className="contact-button" href="tel:+0123456789">
                  <span>CONTACT US</span>
                  <ChevronIcon />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="site-footer">
        <div className="footer-brand">
          <a className="footer-brand__lockup" href="#home" aria-label="Justix home">
            <CourtLogo className="footer-brand__logo" />
            <span className="footer-wordmark">
              <strong>Justix</strong>
              <span>LAW &amp; FIRM</span>
            </span>
          </a>
          <p className="footer-brand__description">
            <span>Lorem ipsum dolor sit amet,</span>
            <span>consectetur adipiscing elit, sed do</span>
            <span>eiusmod tempor incididunt ut labore.</span>
          </p>
        </div>

        <nav className="footer-discover" aria-label="Discover">
          <h2>DISCOVER</h2>
          <ul>
            <li><a href="#about-us">About Us</a></li>
            <li><a href="#about-us">Our Team</a></li>
            <li><a href="#case-studies">Our Cases</a></li>
            <li><a href="#our-blog">Blog</a></li>
          </ul>
        </nav>

        <div className="footer-contact">
          <h2>LET STAY IN TOUCH</h2>
          <div className="footer-contact__list">
            <a href="mailto:info@spstudio.com">
              <MailIcon />
              <span>info@spstudio.com</span>
            </a>
            <div>
              <MapPinIcon />
              <span>15 Division St, New York, 16004</span>
            </div>
          </div>
          <form className="footer-newsletter" onSubmit={handleNewsletterSubmit}>
            <label className="sr-only" htmlFor="newsletter-email">Email address</label>
            <input
              id="newsletter-email"
              type="email"
              name="email"
              autoComplete="email"
              required
              value={newsletterEmail}
              placeholder={newsletterSaved ? "EMAIL SAVED" : "EMAIL ADDRESS"}
              onChange={(event) => {
                setNewsletterEmail(event.target.value);
                setNewsletterSaved(false);
              }}
            />
            <button type="submit" aria-label="Save email address">
              <ChevronIcon />
            </button>
          </form>
        </div>

        <div className="footer-bottom">
          <span className="footer-bottom__line" aria-hidden="true" />
          <div className="footer-social" aria-label="Share Justix">
            <a href={`https://twitter.com/intent/tweet?url=${shareUrl}&text=Justix`} target="_blank" rel="noreferrer" aria-label="Share Justix on Twitter"><TwitterIcon /></a>
            <a href={`https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`} target="_blank" rel="noreferrer" aria-label="Share Justix on Facebook"><FacebookIcon /></a>
            <button type="button" onClick={shareJustix} aria-label="Share Justix"><InstagramIcon /></button>
            <a href={`https://www.pinterest.com/pin/create/button/?url=${shareUrl}&description=Justix`} target="_blank" rel="noreferrer" aria-label="Share Justix on Pinterest"><PinterestIcon /></a>
            <a href={`https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`} target="_blank" rel="noreferrer" aria-label="Share Justix on LinkedIn"><LinkedinIcon /></a>
          </div>
          <span className="footer-bottom__line" aria-hidden="true" />
        </div>
      </footer>
    </main>
  );
}
